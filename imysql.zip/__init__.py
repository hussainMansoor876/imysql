from .assets import MySQL

connect = MySQL

__all__ = ["connect"]
